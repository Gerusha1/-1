const numb = [1, 2, 3, 4, 5];

const arrowFunction = () => 
{
  for (let i = 0; i < numb.length; i++) 
  {
    console.log(numb[i]);
  }
}

arrowFunction();